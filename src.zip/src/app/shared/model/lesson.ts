export class Lesson {
}
