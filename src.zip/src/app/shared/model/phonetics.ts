export class Phonetics {
}
