export class Word {
}
